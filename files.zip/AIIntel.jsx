import { useState, useCallback } from "react";

// ─── FONTS ────────────────────────────────────────────────────────────────────
const FONT_LINK = `
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;0,900;1,400;1,700&family=EB+Garamond:ital,wght@0,400;0,500;1,400&family=UnifrakturMaguntia&family=Libre+Baskerville:ital,wght@0,400;0,700;1,400&display=swap');

  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: #f5f0e8; }

  .ledger-root {
    font-family: 'EB Garamond', Georgia, serif;
    background: #f5f0e8;
    color: #1a1208;
    min-height: 100vh;
  }

  .masthead {
    border-top: 4px solid #1a1208;
    border-bottom: 1px solid #1a1208;
    padding: 12px 0 8px;
    text-align: center;
    position: relative;
  }

  .masthead-kicker {
    font-family: 'Libre Baskerville', serif;
    font-size: 9px;
    letter-spacing: 0.25em;
    text-transform: uppercase;
    color: #4a3728;
    margin-bottom: 4px;
  }

  .masthead-title {
    font-family: 'UnifrakturMaguntia', cursive;
    font-size: 64px;
    line-height: 1;
    color: #1a1208;
    letter-spacing: 0.02em;
  }

  .masthead-subtitle {
    font-family: 'Playfair Display', serif;
    font-style: italic;
    font-size: 13px;
    color: #4a3728;
    margin-top: 2px;
    letter-spacing: 0.05em;
  }

  .masthead-rule {
    height: 3px;
    background: linear-gradient(90deg, transparent, #1a1208 10%, #1a1208 90%, transparent);
    margin: 8px auto;
    max-width: 300px;
  }

  .edition-bar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-top: 1px solid #1a1208;
    border-bottom: 3px double #1a1208;
    padding: 4px 24px;
    margin-top: 8px;
    font-family: 'Libre Baskerville', serif;
    font-size: 10px;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    color: #1a1208;
  }

  .paper-body {
    max-width: 1100px;
    margin: 0 auto;
    padding: 0 24px 48px;
  }

  .section-rule {
    display: flex;
    align-items: center;
    gap: 12px;
    margin: 20px 0 14px;
  }

  .section-rule-line {
    flex: 1;
    height: 1px;
    background: #1a1208;
  }

  .section-rule-label {
    font-family: 'Libre Baskerville', serif;
    font-size: 9px;
    letter-spacing: 0.3em;
    text-transform: uppercase;
    color: #1a1208;
    white-space: nowrap;
    padding: 0 8px;
    border: 1px solid #1a1208;
  }

  .lead-story {
    border-bottom: 2px solid #1a1208;
    padding-bottom: 20px;
    margin-bottom: 0;
  }

  .lead-headline {
    font-family: 'Playfair Display', serif;
    font-size: 38px;
    font-weight: 900;
    line-height: 1.1;
    color: #1a1208;
    margin-bottom: 8px;
  }

  .lead-deck {
    font-family: 'Playfair Display', serif;
    font-style: italic;
    font-size: 16px;
    color: #4a3728;
    margin-bottom: 12px;
    line-height: 1.4;
  }

  .lead-body {
    font-size: 16px;
    line-height: 1.75;
    column-count: 2;
    column-gap: 28px;
  }

  .reporters-take {
    font-family: 'Libre Baskerville', serif;
    font-size: 12px;
    font-style: italic;
    color: #5a4030;
    border-left: 3px solid #1a1208;
    padding-left: 10px;
    margin-top: 10px;
  }

  .columns-grid {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
    gap: 0;
    border-bottom: 1px solid #1a1208;
  }

  .column {
    padding: 16px 20px;
    border-right: 1px solid #1a1208;
  }

  .column:last-child {
    border-right: none;
  }

  .column-head {
    font-family: 'Playfair Display', serif;
    font-size: 17px;
    font-weight: 700;
    line-height: 1.25;
    margin-bottom: 8px;
    color: #1a1208;
  }

  .column-body {
    font-size: 14px;
    line-height: 1.7;
    color: #1a1208;
  }

  .column-kicker {
    font-family: 'Libre Baskerville', serif;
    font-size: 9px;
    letter-spacing: 0.2em;
    text-transform: uppercase;
    color: #8b5e3c;
    margin-bottom: 4px;
  }

  .headline-item {
    padding: 10px 0;
    border-bottom: 1px dotted #8b7355;
  }

  .headline-item:last-child { border-bottom: none; }

  .headline-item-hed {
    font-family: 'Playfair Display', serif;
    font-weight: 700;
    font-size: 15px;
    line-height: 1.25;
    margin-bottom: 3px;
  }

  .headline-item-body {
    font-size: 13px;
    line-height: 1.6;
    color: #2a1a0a;
  }

  .headline-item-source {
    font-family: 'Libre Baskerville', serif;
    font-size: 10px;
    font-style: italic;
    color: #7a5a3a;
    margin-top: 3px;
  }

  .spotlight-box {
    background: #1a1208;
    color: #f5f0e8;
    padding: 20px 24px;
    margin: 20px 0;
  }

  .spotlight-box .col-kicker {
    font-family: 'Libre Baskerville', serif;
    font-size: 9px;
    letter-spacing: 0.3em;
    text-transform: uppercase;
    color: #c4a35a;
    margin-bottom: 8px;
  }

  .spotlight-box .tool-name {
    font-family: 'Playfair Display', serif;
    font-size: 26px;
    font-weight: 700;
    line-height: 1.2;
    margin-bottom: 6px;
  }

  .spotlight-box .tool-meta {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
    margin-top: 14px;
  }

  .spotlight-box .meta-row {
    font-size: 13px;
    line-height: 1.6;
  }

  .spotlight-box .meta-label {
    font-family: 'Libre Baskerville', serif;
    font-size: 9px;
    letter-spacing: 0.15em;
    text-transform: uppercase;
    color: #c4a35a;
    display: block;
    margin-bottom: 2px;
  }

  .bottom-strip {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 0;
    border-top: 3px double #1a1208;
    border-bottom: 3px double #1a1208;
    margin-top: 20px;
  }

  .bottom-col {
    padding: 16px 20px;
    border-right: 1px solid #1a1208;
  }

  .bottom-col:last-child { border-right: none; }

  .dispatch-item {
    font-size: 14px;
    line-height: 1.65;
    padding: 8px 0;
    border-bottom: 1px dotted #8b7355;
  }

  .dispatch-item::before {
    content: "— ";
    font-family: 'Playfair Display', serif;
    font-weight: 700;
  }

  .dispatch-item:last-child { border-bottom: none; }

  .resource-box {
    background: #efe9d8;
    border: 1px solid #8b7355;
    padding: 16px 20px;
  }

  .resource-type {
    display: inline-block;
    font-family: 'Libre Baskerville', serif;
    font-size: 9px;
    letter-spacing: 0.2em;
    text-transform: uppercase;
    border: 1px solid #1a1208;
    padding: 2px 6px;
    margin-bottom: 8px;
  }

  .resource-title {
    font-family: 'Playfair Display', serif;
    font-size: 18px;
    font-weight: 700;
    line-height: 1.3;
    margin-bottom: 6px;
  }

  .resource-desc {
    font-size: 14px;
    line-height: 1.7;
  }

  .resource-link {
    display: inline-block;
    margin-top: 8px;
    font-family: 'Libre Baskerville', serif;
    font-size: 11px;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    color: #1a1208;
    text-decoration: underline;
    text-underline-offset: 3px;
  }

  .colophon {
    border-top: 3px solid #1a1208;
    margin-top: 24px;
    padding-top: 10px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-family: 'Libre Baskerville', serif;
    font-size: 10px;
    letter-spacing: 0.1em;
    color: #5a4030;
    text-transform: uppercase;
  }

  .run-button {
    background: #1a1208;
    color: #f5f0e8;
    border: none;
    padding: 12px 32px;
    font-family: 'Libre Baskerville', serif;
    font-size: 12px;
    letter-spacing: 0.2em;
    text-transform: uppercase;
    cursor: pointer;
    transition: all 0.2s;
    display: block;
    margin: 24px auto 0;
  }

  .run-button:hover {
    background: #3a2a18;
  }

  .run-button:disabled {
    background: #8b7355;
    cursor: not-allowed;
  }

  .loading-state {
    text-align: center;
    padding: 60px 24px;
    font-family: 'Playfair Display', serif;
    font-style: italic;
    font-size: 18px;
    color: #4a3728;
  }

  .loading-ornament {
    font-size: 36px;
    margin-bottom: 16px;
    opacity: 0.5;
  }

  .error-box {
    background: #f5e8e0;
    border: 1px solid #8b3a20;
    padding: 16px 20px;
    margin: 20px 0;
    font-size: 14px;
    color: #5a1a08;
  }

  .welcome-state {
    text-align: center;
    padding: 48px 24px;
    border: 1px dashed #8b7355;
    margin: 24px 0;
  }

  .welcome-ornament {
    font-family: 'Playfair Display', serif;
    font-size: 48px;
    font-style: italic;
    color: #8b7355;
    margin-bottom: 12px;
  }

  .welcome-text {
    font-family: 'Playfair Display', serif;
    font-style: italic;
    font-size: 16px;
    color: #4a3728;
    line-height: 1.8;
  }

  @media (max-width: 768px) {
    .masthead-title { font-size: 40px; }
    .lead-body { column-count: 1; }
    .columns-grid { grid-template-columns: 1fr; }
    .column { border-right: none; border-bottom: 1px solid #1a1208; }
    .spotlight-box .tool-meta { grid-template-columns: 1fr; }
    .bottom-strip { grid-template-columns: 1fr; }
    .bottom-col { border-right: none; border-bottom: 1px solid #1a1208; }
  }
`;

// ─── SYSTEM PROMPT ────────────────────────────────────────────────────────────
const SYSTEM_PROMPT = `You are the editorial intelligence engine for AI INTEL, a daily AI-powered newspaper for accounting and finance professionals.

You MUST respond ONLY with valid JSON — no markdown, no preamble, no backticks. The JSON must exactly match this structure:

{
  "edition": "number or date string",
  "date": "full date string",
  "lead": {
    "headline": "bold front-page headline",
    "deck": "italic subheadline / deck copy",
    "body": "3-4 sentences of lead story content",
    "reportersTake": "one sharp editorial observation"
  },
  "headlines": [
    {
      "headline": "item headline",
      "body": "one sentence summary. Why it matters: one sentence practitioner/founder angle.",
      "source": "publication name"
    }
  ],
  "toolSpotlight": {
    "name": "tool name",
    "company": "company name",
    "what": "2 sentences on what it does",
    "builtFor": "target user description",
    "useCase": "specific CPA firm scenario",
    "pricing": "pricing info or 'Not publicly disclosed'",
    "verdict": "one sharp sentence",
    "link": "URL"
  },
  "agenticCorner": {
    "name": "company or project name",
    "body": "2-3 sentences: what the agent does, deployment model, business structure",
    "strategicRead": "one sentence takeaway for someone building in this space"
  },
  "regulatoryRadar": [
    {
      "agency": "agency name",
      "topic": "topic",
      "summary": "one sentence summary"
    }
  ],
  "regulatoryEmpty": false,
  "regulatoryPending": "what is being monitored if nothing new",
  "resource": {
    "title": "resource title",
    "type": "Article | Paper | Podcast | Course | Repo | Tool",
    "description": "2 sentences: what it covers and why worth the time",
    "link": "URL"
  },
  "dispatch": [
    "sharp analytical observation 1",
    "sharp analytical observation 2",
    "sharp analytical observation 3"
  ]
}

CONTENT RULES:
- Use web search to find real, current news from the last 7 days
- Sources: Journal of Accountancy, CPA Practice Advisor, Accounting Today, Thomson Reuters, Bloomberg Tax, AICPA.org, IRS.gov, TechCrunch, Anthropic/OpenAI/Google/Microsoft blogs
- Do not fabricate headlines, tools, or links
- Practitioner-first framing: connect every item to what a CPA firm does with it
- Secondary founder lens: what does this mean for someone building AI for accounting/tax
- The reader uses UltraTax CS, Fixed Assets CS, QuickBooks Online daily
- If regulatory section has nothing, set regulatoryEmpty to true and populate regulatoryPending
- Include exactly 3-5 headlines, exactly 3 dispatch items`;

// ─── HELPERS ─────────────────────────────────────────────────────────────────
function today() {
  return new Date().toLocaleDateString("en-US", {
    weekday: "long", year: "numeric", month: "long", day: "numeric"
  });
}

function SectionRule({ label }) {
  return (
    <div className="section-rule">
      <div className="section-rule-line" />
      <div className="section-rule-label">{label}</div>
      <div className="section-rule-line" />
    </div>
  );
}

// ─── MAIN COMPONENT ───────────────────────────────────────────────────────────
export default function AIIntel() {
  const [brief, setBrief] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [edition, setEdition] = useState(1);

  const runBrief = useCallback(async () => {
    setLoading(true);
    setError(null);
    setBrief(null);

    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 4000,
          system: SYSTEM_PROMPT,
          tools: [{ type: "web_search_20250305", name: "web_search" }],
          messages: [{
            role: "user",
            content: `Generate today's full AI Intel brief. Today is ${today()}. This is Edition #${edition}. Search the web for the most recent AI in accounting/finance/tax news from the last 7 days. Return ONLY the JSON object as specified.`
          }]
        })
      });

      const data = await response.json();

      // Extract text from content blocks
      const textBlocks = data.content
        .filter(b => b.type === "text")
        .map(b => b.text)
        .join("");

      if (!textBlocks) throw new Error("No text response received from API.");

      // Clean and parse JSON
      const clean = textBlocks
        .replace(/```json/g, "")
        .replace(/```/g, "")
        .trim();

      // Find JSON object
      const jsonStart = clean.indexOf("{");
      const jsonEnd = clean.lastIndexOf("}");
      if (jsonStart === -1 || jsonEnd === -1) throw new Error("Could not locate JSON in response.");

      const parsed = JSON.parse(clean.slice(jsonStart, jsonEnd + 1));
      setBrief(parsed);
      setEdition(e => e + 1);
    } catch (err) {
      setError(err.message || "An error occurred generating the brief.");
    } finally {
      setLoading(false);
    }
  }, [edition]);

  return (
    <>
      <style>{FONT_LINK}</style>
      <div className="ledger-root">

        {/* ── MASTHEAD ── */}
        <div className="masthead">
          <div className="masthead-kicker">Est. 2025 · AI × Accounting & Finance Intelligence</div>
          <div className="masthead-title">AI Intel</div>
          <div className="masthead-rule" />
          <div className="masthead-subtitle">"All the intelligence that's fit to print."</div>
        </div>

        <div className="edition-bar">
          <span>Edition No. {brief?.edition || edition}</span>
          <span>{brief?.date || today()}</span>
          <span>Published Daily · Powered by Claude</span>
        </div>

        <div className="paper-body">

          {/* ── WELCOME / IDLE STATE ── */}
          {!brief && !loading && !error && (
            <>
              <div className="welcome-state">
                <div className="welcome-ornament">§</div>
                <div className="welcome-text">
                  Good morning. Your edition is ready to be printed.<br />
                  Press the button below to fetch today's intelligence.
                </div>
              </div>
              <button className="run-button" onClick={runBrief}>
                ▶ Print Today's Edition
              </button>
            </>
          )}

          {/* ── LOADING STATE ── */}
          {loading && (
            <div className="loading-state">
              <div className="loading-ornament">✦</div>
              <div>Setting the type for today's edition…</div>
              <div style={{ fontSize: 13, marginTop: 8, opacity: 0.7 }}>Searching the wire for today's intelligence</div>
            </div>
          )}

          {/* ── ERROR STATE ── */}
          {error && (
            <>
              <div className="error-box">
                <strong>Press Dispatch Error:</strong> {error}
              </div>
              <button className="run-button" onClick={runBrief}>Retry</button>
            </>
          )}

          {/* ── BRIEF CONTENT ── */}
          {brief && (
            <>
              {/* ABOVE THE FOLD */}
              <SectionRule label="Above the Fold" />
              <div className="lead-story">
                <div className="lead-headline">{brief.lead?.headline}</div>
                <div className="lead-deck">{brief.lead?.deck}</div>
                <div className="lead-body">{brief.lead?.body}</div>
                {brief.lead?.reportersTake && (
                  <div className="reporters-take">Reporter's Take: {brief.lead.reportersTake}</div>
                )}
              </div>

              {/* HEADLINES + TOOL SPOTLIGHT + AGENTIC CORNER — 3 columns */}
              <SectionRule label="Today's Intelligence" />
              <div className="columns-grid">

                {/* Col 1: Headlines */}
                <div className="column">
                  <div className="column-kicker">Today's Headlines</div>
                  {(brief.headlines || []).map((h, i) => (
                    <div className="headline-item" key={i}>
                      <div className="headline-item-hed">{h.headline}</div>
                      <div className="headline-item-body">{h.body}</div>
                      {h.source && <div className="headline-item-source">— {h.source}</div>}
                    </div>
                  ))}
                </div>

                {/* Col 2: Tool Spotlight */}
                <div className="column">
                  <div className="column-kicker">Tool Spotlight</div>
                  {brief.toolSpotlight && (
                    <>
                      <div className="column-head">{brief.toolSpotlight.name}</div>
                      <div className="column-body">
                        <p style={{ marginBottom: 8 }}><em>By {brief.toolSpotlight.company}</em></p>
                        <p style={{ marginBottom: 8 }}>{brief.toolSpotlight.what}</p>
                        <p style={{ marginBottom: 6 }}><strong>Built for:</strong> {brief.toolSpotlight.builtFor}</p>
                        <p style={{ marginBottom: 6 }}><strong>CPA use case:</strong> {brief.toolSpotlight.useCase}</p>
                        <p style={{ marginBottom: 6 }}><strong>Pricing:</strong> {brief.toolSpotlight.pricing}</p>
                        <p style={{ fontStyle: "italic", marginBottom: 6 }}>{brief.toolSpotlight.verdict}</p>
                        {brief.toolSpotlight.link && (
                          <a href={brief.toolSpotlight.link} target="_blank" rel="noopener noreferrer"
                            style={{ fontSize: 11, fontFamily: "'Libre Baskerville', serif", letterSpacing: "0.1em", textTransform: "uppercase", color: "#1a1208" }}>
                            → Visit
                          </a>
                        )}
                      </div>
                    </>
                  )}
                </div>

                {/* Col 3: Agentic Corner */}
                <div className="column">
                  <div className="column-kicker">The Agentic Corner</div>
                  {brief.agenticCorner && (
                    <>
                      <div className="column-head">{brief.agenticCorner.name}</div>
                      <div className="column-body">
                        <p style={{ marginBottom: 10 }}>{brief.agenticCorner.body}</p>
                        <div style={{ borderTop: "1px solid #8b7355", paddingTop: 8, fontStyle: "italic", fontSize: 13 }}>
                          <strong>Strategic read:</strong> {brief.agenticCorner.strategicRead}
                        </div>
                      </div>
                    </>
                  )}
                </div>
              </div>

              {/* TOOL SPOTLIGHT — full-width black box */}
              <SectionRule label="Regulatory Radar" />
              <div style={{ padding: "12px 0" }}>
                {brief.regulatoryEmpty ? (
                  <p style={{ fontStyle: "italic", fontSize: 14, color: "#5a4030" }}>
                    No new AI-specific regulatory guidance issued in the last 7 days.
                    {brief.regulatoryPending && ` Monitoring: ${brief.regulatoryPending}`}
                  </p>
                ) : (
                  (brief.regulatoryRadar || []).map((r, i) => (
                    <div key={i} style={{ padding: "8px 0", borderBottom: "1px dotted #8b7355" }}>
                      <strong style={{ fontFamily: "'Libre Baskerville', serif", fontSize: 11, letterSpacing: "0.1em", textTransform: "uppercase" }}>
                        {r.agency}
                      </strong>
                      {" — "}
                      <strong>{r.topic}:</strong> {r.summary}
                    </div>
                  ))
                )}
              </div>

              {/* RESOURCE + DISPATCH — 2 columns */}
              <div className="bottom-strip">
                <div className="bottom-col">
                  <div style={{ fontFamily: "'Libre Baskerville', serif", fontSize: 9, letterSpacing: "0.3em", textTransform: "uppercase", marginBottom: 12 }}>
                    Resource of the Day
                  </div>
                  {brief.resource && (
                    <div className="resource-box">
                      <span className="resource-type">{brief.resource.type}</span>
                      <div className="resource-title">{brief.resource.title}</div>
                      <div className="resource-desc">{brief.resource.description}</div>
                      {brief.resource.link && (
                        <a href={brief.resource.link} target="_blank" rel="noopener noreferrer" className="resource-link">
                          → Read / Access
                        </a>
                      )}
                    </div>
                  )}
                </div>

                <div className="bottom-col">
                  <div style={{ fontFamily: "'Libre Baskerville', serif", fontSize: 9, letterSpacing: "0.3em", textTransform: "uppercase", marginBottom: 12 }}>
                    Editor's Dispatch
                  </div>
                  {(brief.dispatch || []).map((d, i) => (
                    <div className="dispatch-item" key={i}>{d}</div>
                  ))}
                </div>
              </div>

              {/* COLOPHON */}
              <div className="colophon">
                <span>AI Intel · Est. 2025</span>
                <span>AI-generated · Verify before acting professionally</span>
                <span>Powered by Claude Sonnet</span>
              </div>

              {/* NEXT EDITION BUTTON */}
              <button className="run-button" onClick={runBrief} disabled={loading}>
                {loading ? "Setting the type…" : "▶ Print Next Edition"}
              </button>
            </>
          )}
        </div>
      </div>
    </>
  );
}
